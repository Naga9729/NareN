package com.springboot.beginner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMar291Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMar291Application.class, args);
	}

}
