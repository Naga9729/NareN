package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Friend;
import com.example.demo.service.FriendService;

@RestController
public class WelcomeController {
	
	@Autowired
	private FriendService friendservice;
	
	@RequestMapping(value="/welcome", method=RequestMethod.GET)
	public String welcome() {
		return "Hi, ****GET******";
		
	}
	
	@RequestMapping(value="/welcome", method=RequestMethod.POST)
	public String welcomePost() {
		return "Hi, ****POST******";
		
	}
	
	@RequestMapping(value="/welcome", method=RequestMethod.PUT)
	public String welcomePut() {
		return "Hi, ****PUT******";
		
	}
	
	@RequestMapping(value="/welcome", method=RequestMethod.DELETE)
	public String welcomeDelete() {
		return "Hi, ****DEL******";
		
	}
	
	@GetMapping("/new1")
	public List<Friend> listFriends() {
		
		return friendservice.getAllFriends();

	}
	
	@RequestMapping(value="/new/{id}")
	public Friend getFriendById(@PathVariable String id) {
		return friendservice.getFriendById(id);
		
	}

	
}
