package com.example.demo.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.pojo.Friend;

@Repository
public class FriendDao {

	private List<Friend> friends = new ArrayList<Friend>(Arrays.asList(
			new Friend ("sdhfg",21,"001"),
			new Friend ("xcxcdfg",24,"002"),
			new Friend ("fghgh",23,"003")
			));
	
	public List<Friend> getAllFriends() {
		
		/*List<Friend> friends = new ArrayList<>();
		Friend f1 = new Friend();
		f1.setAge(20);
		f1.setName("xmcnmz");
		
		Friend f2 = new Friend();
		f2.setAge(24);
		f2.setName("sajdgha");
		
		friends.add(f1);
		friends.add(f2);   */
		
		return friends;
		
	}
	
	public Friend getFriendById(String id ) {
		
		return friends.stream().filter((f) -> f.getId().equals(id)).findFirst().get();
	}

}
